-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 16 Apr 2019 pada 16.23
-- Versi server: 10.1.37-MariaDB
-- Versi PHP: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pw_1384050057`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `daftar_film`
--

CREATE TABLE `daftar_film` (
  `id` int(11) NOT NULL,
  `judul_film` varchar(64) NOT NULL,
  `sutradara` varchar(64) NOT NULL,
  `genre` varchar(64) NOT NULL,
  `produser` varchar(64) NOT NULL,
  `foto` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `daftar_film`
--

INSERT INTO `daftar_film` (`id`, `judul_film`, `sutradara`, `genre`, `produser`, `foto`) VALUES
(1, 'Dilan 1991', 'Pidi Baiq, Fajar Bustomi', 'Drama/Film Roman', 'Ody Mulya Hidayat', 'a.jpg'),
(2, 'Dilan 1990', 'Pidi Baiq, Fajar Bustomi', 'Drama/Film Roman	', 'Pidi Baiq', 'b.jpg'),
(3, 'Pengabdi Setan', 'Joko Anwar', 'Misteri/Drama', 'Gope T. Samtani', 'c.jpg'),
(4, 'Yowis Ben', 'Bayu Skak, Fajar Nugros	', 'Drama/Komedi', 'Chand Parwez Servia', 'd.jpg'),
(5, 'Keluarga Cemara', 'Yandy Laurens', 'Drama/Keluarga	', 'Visinema Pictures', 'e.jpg'),
(6, 'Danur', 'Awi Suryadi', 'Horor', 'Dian W. Sasmita', 'f.jpg'),
(7, 'Dear Nathan', 'Indra Gunawan', 'Drama/Film remaja', 'Erisca Febriani', 'g.jpg'),
(8, 'London Love Story 3', 'Asep Kusdinar', 'Drama/Film Roman', 'Sukhdev Singh, Wicky V. Olindo', 'h.jpg'),
(9, 'Danur 2: Maddah', 'Awi Suryadi', 'Horor', 'Manoj Punjabi', 'i.jpg'),
(10, 'Ayat Ayat Cinta 2', 'Guntur Soehardjanto', 'Drama', 'Manoj Punjabi, Dhamoo Punjabi\r\n', 'j.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `mahasiswa`
--

CREATE TABLE `mahasiswa` (
  `id` int(11) NOT NULL,
  `nrp` char(9) NOT NULL,
  `nama` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `jurusan` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `mahasiswa`
--

INSERT INTO `mahasiswa` (`id`, `nrp`, `nama`, `email`, `jurusan`) VALUES
(1, '183040057', 'M Syamsul Hadi R', 'samsultea42@gmail.com', 'Teknik Informatika'),
(2, '183040050', 'Anan', 'anan@gmail.com', 'Teknik Pangan'),
(3, '183040058', 'Juned Bin Ubed', 'juned@gmail.com', 'Teknik Pangan'),
(4, '183040078', 'Abdul', 'abdul@gmail.com', 'Teknik Mesin'),
(5, '183040043', 'Somad', 'somad@gmail.com', 'Teknik Industri'),
(8, '183040090', 'Ferguso', 'ferguso@gmail.com', 'Teknik Informatika'),
(9, '183040091', 'Pitri', 'pitri@gmail.com', 'Teknik Mesin');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `daftar_film`
--
ALTER TABLE `daftar_film`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `nama` (`nama`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `daftar_film`
--
ALTER TABLE `daftar_film`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT untuk tabel `mahasiswa`
--
ALTER TABLE `mahasiswa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
