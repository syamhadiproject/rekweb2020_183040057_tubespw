<?php
//Connect To Databases
$conn = mysqli_connect('localhost', 'root', '', 'pw_1384050057');

function query($query) {
	global $conn;
	$result = mysqli_query($conn, $query);
	$rows = [];
	while( $row = mysqli_fetch_assoc($result)) {
		$rows[] = $row;
	}
	return $rows;
}



function tambah($data) {
	global $conn;
	
	$film = htmlspecialchars($data["judul_film"]);
	$sutra = htmlspecialchars($data["sutradara"]);
	$genre = htmlspecialchars($data["genre"]);
	$pro = htmlspecialchars($data["produser"]);
	$photo = htmlspecialchars($data["foto"]);
	
	// Query insert data 
	$query = "INSERT INTO daftar_film VALUES 
				('', '$film', '$sutra', '$genre', '$pro', '$photo')
			 ";
	mysqli_query($conn, $query);
	
	return mysqli_affected_rows($conn);
}



function hapus($id) {
	global $conn;
	mysqli_query($conn, "DELETE FROM daftar_film WHERE id = $id");
	
	return mysqli_affected_rows($conn);
}


function ubah($data) {
	global $conn;
	
	$id = $data["id"];
	$film = htmlspecialchars($data["judul_film"]);
	$sutra = htmlspecialchars($data["sutradara"]);
	$genre = htmlspecialchars($data["genre"]);
	$pro = htmlspecialchars($data["produser"]);
	$photo = htmlspecialchars($data["foto"]);
	
	// Query insert data 
	$query = "UPDATE daftar_film SET 
				judul_film = '$film',
				sutradara = '$sutra',
				genre = '$genre',
				produser = '$pro',
				foto = '$photo'
			 WHERE id = $id
			 ";
	mysqli_query($conn, $query);
	
	return mysqli_affected_rows($conn);
}

function cari($keyword) {
	$query = "SELECT * FROM daftar_film WHERE
				judul_film LIKE '%$keyword%' OR
				sutradara LIKE '%$keyword%' OR
				genre LIKE '%$keyword%' OR
				produser LIKE '%$keyword%'
			";
	return query($query);
}








?>
