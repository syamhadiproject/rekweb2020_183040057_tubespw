<?php

require 'funtions.php';

$id = $_GET["id"];


if( hapus($id) > 0 ) {
		print "
			<script>
				alert('Data Berhasil dihapus!');
				document.location.href = 'indexs.php';
			</script>
		";
	} else {
		print "
			<script>
				alert('Data Gagal dihapus!');
				document.location.href = 'indexs.php';
			</script>
		";
}

?>