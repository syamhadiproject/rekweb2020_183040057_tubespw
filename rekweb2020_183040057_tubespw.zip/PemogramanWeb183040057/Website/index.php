 <?php
require 'funtions.php';
 $film = query("SELECT * FROM daftar_film");


if( isset($_POST["cari"]) ) {
	$film = cari($_POST["keyword"]);
}

if (isset($_POST['submit'])) {
	if ($_POST['username'] == 'admin' && $_POST['password'] == 'admin') {
		header("location: indexs.php");
		exit;
	} else {
		$nValid = true;
	}
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Welcome To Syam Hadi Project</title>
    <!-- Bootstrap -->
    <link href="css/bootstrap-4.3.1.css" rel="stylesheet">
  </head>
	<style>
		.container2 {
			border: 1px solid black;
			border-radius: 50px;
			text-align: center;
			font-size: 20px;
			background-color : #D5D5D5;
			margin: auto;
			height: 100%;
			width: 50%;
		}
	</style>
  <body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <a class="navbar-brand" href="index.php">Youtube</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active"> <a class="nav-link" href="login_admin.php">Admin <span class="sr-only">(current)</span></a> </li>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="#">Action</a> <a class="dropdown-item" href="#">Another action</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="#">Something else here</a> 
            </div>
          </li>
        </ul>
		
        <form class="form-inline my-2 my-lg-0" action="" method="post">
		  <input class="form-control mr-sm-2" type="text" name="keyword" placeholder="Search Keyword..." autocomplete="off">
          <button class="btn btn-outline-success my-2 my-sm-0" type="submit" name="cari">Search</button>
        </form>
      </div>
    </nav>
    <header>
      <div class="jumbotron">
        <div class="container">
          <div class="row">
            <div class="col-12">
              <h1 class="text-center">Welcome To My Youtube Channel</h1>
				<h3 class="text-center">Syam Hadi Project | Musik Nyantuy</h3>
			  <p>
              <p class="text-center">Hallo !!! Nama Saya Muhammad Syamsul Hadi Rahman, saya tinggal di Cianjur, Umur saya sekarang 20 tahun. Saya Mahasiswa Universitas Pasundan (Bandung), Jurusan yang saya ambil yaitu Teknik Informatika. </p>
              <p class="text-center">Disini saya hanya berbagi hobi saya lewat website yang saya buat. Hobi saya tidak hanya bermain game, tetapi saya juga suka nonton film, jadi saya hanya share film yang populer pada jamannya, kalian bisa baca di menu "ABOUT US"</p>
			  </p>
              <p>&nbsp;</p>
            </div>
          </div>
        </div>
      </div>
  </header>
    <section>
      <div class="container">
        <div class="row">
          <div class="col-lg-12 mb-4 mt-2 text-center">
            <h2>ABOUT US</h2>
          </div>
        </div>
      </div>
		
      <center><div class="container2">
		 
        <div class="row">
          <div class="container">
	 
 			<?php foreach ($film as $flm) : ?>
        <div class="content">
			<p>
           <div class="gambar">
                   <p><img src="assets/img/<?= $flm['foto']; ?>">
           </div> </p>
            <p class="nama">
				<a href="profile.php?id=<?= $flm['id']; ?>"><?= $flm['judul_film']; ?></a>
			</p>
			<p><?= $flm['sutradara']; ?></p>
			<?php endforeach; ?>
        </div>
 	</div>
      </div>
		</div>
		   </center>
		
    </section>

    <footer class="text-center">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <p>Copyright © MyWebsite. All rights reserved.</p>
          </div>
        </div>
      </div>
    </footer>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
    <script src="js/jquery-3.3.1.min.js"></script> 
    <!-- Include all compiled plugins (below), or include individual files as needed --> 
    <script src="js/popper.min.js"></script> 
    <script src="js/bootstrap-4.3.1.js"></script>
  </body>
</html>