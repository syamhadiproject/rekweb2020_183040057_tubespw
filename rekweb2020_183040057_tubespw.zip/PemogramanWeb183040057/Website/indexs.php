 <?php
//Connect To Databases => funtions
require 'funtions.php';
//Query data Tabel Film
$film = query("SELECT * FROM daftar_film");


if( isset($_POST["cari"]) ) {
	$film = cari($_POST["keyword"]);
}
 
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Halaman Administrator</title>
    <!-- Bootstrap -->
    <link href="css/bootstrap-4.3.1.css" rel="stylesheet">
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <a class="navbar-brand" href="indexs.php">Youtube</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active"> <a class="nav-link" href="index.php">Logout <span class="sr-only">(current)</span></a> </li>
			<li class="nav-item active"> <a class="nav-link" href="tambah.php">Add Video <span class="sr-only">(current)</span></a> </li>
          </li>
        </ul>
		
        <form class="form-inline my-2 my-lg-0" action="" method="post">
		  <input class="form-control mr-sm-2" type="text" name="keyword" placeholder="Search Keyword..." autocomplete="off">
          <button class="btn btn-outline-success my-2 my-sm-0" type="submit" name="cari">Search</button>
        </form>
      </div>
    </nav>
    <header>
      <div class="jumbotron">
        <div class="container">
          <div class="row">
            <div class="col-12">
              <h1 class="text-center">Selamat Anda Sebagai Administrator</h1>
				<h3 class="text-center">Syam Hadi Project | Musik Nyantuy</h3>
				<p>                
				<p>
			  <p class="text-center">Bijaksanalah Dalam Merubah Data</p>
				</p>
              <p>&nbsp;</p>
            </div>
          </div>
        </div>
      </div>
  </header>
    <section>
      <div class="container">
        <div class="row">
          <div class="col-lg-12 mb-4 mt-2 text-center">
            <h2>UBAH CONTENT</h2>
          </div>
        </div>
      </div>
		
	<div class="col-lg-12 mb-4 mt-2 text-center">
     <table class="table table-striped table-dark">
			<tr>
				<th>No</th>
				<th>Opsi</th>
				<th>Photo</th>
				<th>Judul Film</th>
				<th>Sutradara</th>
				<th>Genre</th>
				<th>Produser</th>
			</tr>
		</thead>
			<?php $i = 1; ?>	
				<?php foreach($film as $flm) : ?>
			<tr>
				<td><?= $i++; ?></td>
				<td> <button class="btn btn-outline-success my-2 my-sm-0"><a href="ubah.php?id=<?= $flm["id"]; ?> ">Change</button></a> | 
					<button class="btn btn-outline-success my-2 my-sm-0"><a href="hapus.php?id=<?= $flm["id"]; ?>" onClick="return confirm('Yakin akan dihapus?')">Delete</button></a>
				</td>
				<td><img src="assets/img/<?= $flm['foto']; ?>"></td>
				<td><?= $flm['judul_film']; ?></td>
				<td><?= $flm['sutradara']; ?></td>
				<td><?= $flm['genre']; ?></td>
				<td><?= $flm['produser']; ?></td>
			</tr>
				<?php endforeach; ?>
	</table>
	</div>
    </section>

    <footer class="text-center">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <p>Copyright © MyWebsite. All rights reserved.</p>
          </div>
        </div>
      </div>
    </footer>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
    <script src="js/jquery-3.3.1.min.js"></script> 
    <!-- Include all compiled plugins (below), or include individual files as needed --> 
    <script src="js/popper.min.js"></script> 
    <script src="js/bootstrap-4.3.1.js"></script>
  </body>
</html>