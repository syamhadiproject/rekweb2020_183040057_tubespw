<?php  
if (isset($_POST['submit'])) {
	if ($_POST['username'] == 'admin' && $_POST['password'] == 'admin') {
		header("location: indexs.php");
		exit;
	} else {
		$nValid = true;
	}
}
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Login Admin</title>

	<style>
		body {
			text-align: center;
		}

		img {
			width: 200px;
			height: 200px;
		}
		h1 {
			text-shadow: 2px 2px 5px white;
		}
		input[type=text], select {
		  width: 400px;
		  padding: 12px 20px;
		  margin: 8px 0;
		  display: inline-block;
		  border: 1px solid #ccc;
		  border-radius: 4px;
		  box-sizing: border-box;
		}
		input[type=password], select {
		  width: 400px;
		  padding: 12px 20px;
		  margin: 8px 0;
		  display: inline-block;
		  border: 1px solid #ccc;
		  border-radius: 4px;
		  box-sizing: border-box;
		}

		input[type=submit] {
		  width: 100px;
		  background-color: #4CAF50;
		  color: white;
		  padding: 14px 20px;
		  margin: 8px 0;
		  border: none;
		  border-radius: 4px;
		  cursor: pointer;
		}

		input[type=submit]:hover {
		  background-color: #45a049;
		}

		div {
		  border-radius: 5px;
		  background-color:#6e979e;
		  padding: 109px;
		}
	</style>

</head>	
<body>
<div>
	<h1>Login Sebagai Administrator</h1>
	<img src="assets/img/nony.png" alt="user">
	<?php if(isset($nValid)): ?>
		<p style="color: red; font-style: italic;">Maaf, Username atau Password Anda Salah!</p>
	<?php endif ?>
  <form action="" method="post">
	<p>
    <label for="fname">Username :</label>
	</p>
    <input type="text"  name="username" placeholder="Masukan Username...">
	<p>
    <label for="lname">Password :</label>
	</p>
    <input type="password"  name="password" placeholder="Masukan Password...">
	<P>
    <input type="submit" name="submit" value="Login">